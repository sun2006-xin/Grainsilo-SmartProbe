# Windows 便携包对应源码

ZIP 内的 SOURCE-CODE/ 目录包含与“粮仓集成监控中心.exe”对应的电脑端应用源码、网页资源、构建脚本、构建依赖说明和相关许可证。可在 Windows PowerShell 与 Python 3.11 环境中运行仓库工具目录下的 build_station_user.ps1 重新构建；脚本会创建隔离构建环境并下载固定版本的 PyInstaller 依赖。

该源码包提供 Windows 中心站。S3/C3 固件与 AutoLink 源码可在 GitHub 上的 GrainSilo 仓库获取。

随包 LICENSE 为 Apache-2.0。第三方组件保留各自许可。

用户数据库、设备历史记录、真实设备 UID、Wi-Fi 凭据和本机网络配置不包含在此源码包中。
